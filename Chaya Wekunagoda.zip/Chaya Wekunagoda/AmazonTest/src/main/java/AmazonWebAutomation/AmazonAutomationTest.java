package AmazonWebAutomation;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class AmazonAutomationTest {
    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
    	System.setProperty("webdriver.chrome.driver", "C:/Users/AD/chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        // Maximize browser
        driver.manage().window().maximize();
        
        // 1.Navigate to Amazon site
        driver.get("https://www.amazon.com/");
        
       // 2. Select 'Books' from the Category list
        WebElement categoryDropdown = driver.findElement(By.id("searchDropdownBox"));
        Select categorySelect = new Select(categoryDropdown);
        categorySelect.selectByVisibleText("Books");

        // 3. Search for the term "Automation"
        WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
        searchBox.sendKeys("Automation");
        searchBox.submit();
        
        // 4. Find and click the search button
        WebElement searchButton = driver.findElement(By.cssSelector("input[value='Go']"));
        searchButton.click();

        // 5. Find and click the "4 Stars & Up" filter for customer reviews
        WebElement fourStarsAndUpFilter = driver.findElement(By.cssSelector("i.a-icon-star-medium.a-star-medium-4"));
        fourStarsAndUpFilter.click();
        
         //To perform Scroll on application 
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,350)", "");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        // 5. Select Language as "English"
        WebElement englishLanguage = driver.findElement(By.xpath("//span[text()='English']"));
        englishLanguage.click();

        // 6. Get the name of the second item from the Product List page
        WebElement secondItem = driver.findElement(By.xpath("(//span[@class='a-size-medium a-color-base a-text-normal'])[2]"));
        String secondItemName = secondItem.getText();

        // 7. Click the second item and navigate to the Product Detail page
        secondItem.click();
        // 8. Get the unit price from the Product Detail page
        WebElement unitPriceElement = driver.findElement(By.id("a-autoid-13"));
        String unitPrice = unitPriceElement.getText();
       
       // 9. Verify whether the item name matches 
        WebElement productTitleElement = driver.findElement(By.id("productTitle"));
        String productTitle = productTitleElement.getText();

       if (productTitle.equals(secondItemName)) {
            System.out.println("Item names match.");
       } else {
            System.out.println("Item names do not match.");}
        
       //10. Set the Quantity to 2
      
       WebElement quantity = driver.findElement(By.xpath("//Select[@id=\"quantity\"]"));
       Select se =new Select (quantity);
       se.selectByIndex(1);
       
      // 11. Click on Add to Cart.
         WebElement addToCartButton = driver.findElement(By.id("add-to-cart-button"));
         addToCartButton.click();
         
      // 12. Click on Go to Cart.
         
         WebElement goToCartButton = driver.findElement(By.xpath("//a[@data-csa-c-slot-id='sw-gtc']"));
         goToCartButton.click();

      // 13. Verify whether the cart details are correct.
         
         WebElement cartItemName = driver.findElement(By.xpath("//span[@class='a-truncate-cut']"));
         String cartItemTitle = cartItemName.getText();
         WebElement cartQuantity = driver.findElement(By.xpath("//span[@class='a-dropdown-prompt']"));
         String cartQuantityValue = cartQuantity.getText();;
         WebElement cartTotalPrice = driver.findElement(By.xpath("//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap']"));
         String cartTotalPriceValue = cartTotalPrice.getText();

         System.out.println("Cart Item: " + cartItemTitle);
         System.out.println("Cart Quantity: " + cartQuantityValue);
         System.out.println("Cart Total Price: " + cartTotalPriceValue);
         
       // 14. Clear the cart and verify the total amount is $0.00 
         
         Actions act = new Actions(driver);
         WebElement ele = driver.findElement(By.xpath("//input[@value='Delete']")); 
         act.doubleClick(ele).perform();
         
         driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
         
         WebElement emptyCartMessage = driver.findElement(By.xpath("//div[@class='a-row sc-cart-header']"));
         String emptyCartMessageText = emptyCartMessage.getText();

         if (emptyCartMessageText.contains("Your Amazon Cart is empty")) {
             System.out.println("Cart is empty.");
         } else {
             System.out.println("Cart is not empty.");
         }
         
        
        // Close the browser
        driver.quit();
    }


}





